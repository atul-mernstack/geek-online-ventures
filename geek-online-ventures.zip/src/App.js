import {Route, Link, Switch, BrowserRouter} from 'react-router-dom';
import Home from './components';
import SignupLogin from './components/signup-login';
import Signin from './components/sign-in';
import Signup from './components/sign-up';
import MainThreads from './components/navbar';
import ForgotPassword from './components/forgot-password';
import './App.css';
import { useState } from 'react';

function App() {
  const [flag, setFlag]=useState(false);
  return (
    <BrowserRouter>
    <div className="App"> 
    {flag?<MainThreads/>:null}
    <Switch>      
      <Route exact path="/"><Home/></Route> 
      <Route exact path="/signup-login"><SignupLogin/></Route>
    <Route exact path="/sign-up"><Signup/></Route>
    <Route exact path="/sign-in"><Signin setFlag={setFlag}/></Route>
    <Route exact path="/forgot-password"><ForgotPassword setFlag={setFlag}/></Route>
    </Switch>
    </div>
    
    </BrowserRouter>
  );
}

export default App;

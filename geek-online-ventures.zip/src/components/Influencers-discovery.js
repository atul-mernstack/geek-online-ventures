import './style.css';

const InfluencerDiscovery=()=>{
    return(
        <>
        <section className="detailed-insight-sec">
         <div className="container-fluid">
             
            <div className="row">
               <div className="col-6">
                  <div className="insight-sec">
                     <img src={"/images/virat-txt.png"} className="img-fluid"/>
                  </div>
               </div>
               <div className="col-6">
                  <div className="insight-sec">
                     <img src={"/images/virat-txt.png"} className="img-fluid"/>
                  </div>
               </div>
               <div className="col-6">
                  <div className="insight-sec">
                     <img src={"/images/virat-txt.png"} className="img-fluid"/>
                  </div>
               </div>
               <div className="col-6">
                  <div className="insight-sec">
                     <img src={"/images/virat-txt.png"} className="img-fluid"/>
                  </div>
               </div>
               <div className="col-6">
                  <div className="insight-sec">
                     <img src={"/images/virat-txt.png"} className="img-fluid"/>
                  </div>
               </div>
               <div className="col-6">
                  <div className="insight-sec">
                     <img src={"/images/virat-txt.png"} className="img-fluid"/>
                  </div>
               </div>
               <div className="col-6">
                  <div className="insight-sec">
                     <img src={"/images/virat-txt.png"} className="img-fluid"/>
                  </div>
               </div>
               <div className="col-6">
                  <div className="insight-sec">
                     <img src={"/images/virat-txt.png"} className="img-fluid"/>
                  </div>
               </div>
               <div className="col-6">
                  <div className="insight-sec">
                     <img src={"/images/virat-txt.png"} className="img-fluid"/>
                  </div>
               </div>
            </div>
         </div>
      </section>
        </>
    )
}

export default InfluencerDiscovery;
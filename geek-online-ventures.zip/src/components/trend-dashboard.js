import {Link} from 'react-router-dom';
import './style.css';

const Trend=()=>{
    return(
        <>
        <section className="trend-dashboard">
         <div className="container-fluid mt-2">
         <div className="row">
            <div className="col-12">
               <div className="heading-sec">
                  <h4 style={{textDecorationColor:"orange"}}>Create trends dashboard</h4>
               </div>
            </div>
         </div>
         <div className="row">
            <div className="col-12">
               <form>
                  <div className="form-group">
                     <label for="Brands">Brands</label>
                     <input type="text" className="form-control" id="Brands" aria-describedby="Brands"/>
                  </div>
                  <div className="form-group">
                     <label for="Hashtagorcaption">Hashtag or caption</label>
                     <input type="text" className="form-control" id="Hashtagorcaption" aria-describedby="Hashtagorcaption"/>
                  </div>
                  <div className="form-group">
                     <div className="row">
                        <div className="col-6">
                           <label for="from">From</label>
                           <div className="input-group date" id="datetimepicker1">
                              <input id="datepicker" width="100%" className="form-control hasDatepicker"/>
                              <span className="input-group-addon">
                              <i className="fa fa-calendar-o" aria-hidden="true"></i>
                              </span>
                           </div>
                        </div>
                        <div className="col-6">
                           <label for="to">To</label>
                           <div className="input-group date" id="datetimepicker2">
                              <input id="datepicker2" width="100%" className="form-control hasDatepicker"/>
                              <span className="input-group-addon">
                              <i className="fa fa-calendar-o" aria-hidden="true"></i>
                              </span>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div className="form-group">
                     <label for="Brands">Metric</label>
                     <select className="form-control" id="Metric">
                        <option>Metric</option>
                        <option>Metric</option>
                        <option>Metric</option>
                        <option>Metric</option>
                        <option>Metric</option>
                     </select>
                  </div>
                  <div className="form-group">
                     <label for="location">Locations (Country or City)</label>
                     <select className="form-control" id="loaction">
                        <option>India</option>
                        <option>USA</option>
                        <option>UK</option>
                        <option>Africa</option>
                        <option>UAE</option>
                     </select>
                  </div>
                  <div className="form-group">
                     <label for="Granlurity">Granlurity</label>
                     <div className="btn-group" role="group" aria-label="Basic example">
                        <button type="button" className="btn btn-danger btn-lg active">Influencer</button>
                        <button type="button" className="btn btn-danger btn-lg">Audience</button>
                        <button type="button" className="btn btn-danger btn-lg">Group</button>
                     </div>
                     <label for="Sponsored" className="mt-3">Sponsored</label>
                  </div>
                  
                  <div className="form-group radiored-btn">
                     <label className="radio-inline">
                     <input type="checkbox" id="defaultCheck" name="example2"/>
                     <label for="defaultCheck">Only show sponsored</label>
                     </label>
                  </div>
               </form>
               <div className="form-group mb-5">
                  <div className="r-btns">
                     <ul>
                        <li><Link to="/trend-dashboard" className="btn bnt-md btn-danger">Create Dashboard</Link></li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </div></section>
        </>
    )
}
export default Trend;
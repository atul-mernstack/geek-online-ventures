import './style.css';

const Campaign1=()=>{
    return(
        <>
        <section className="campaign-sec">
         <div className="container-fluid">
            <div className="row">
               <div className="col-5 col-md-9 my-auto">
                  <div className="active-txt">
                     <h6 className="text-left">Active Campaigns: 3</h6>
                  </div>
               </div>
               <div className="col-7 col-md-3  ml-md-auto">
                  <a href="#" className="btn btn-md btn-danger" data-toggle="modal" data-target="#exampleModalCenter">Create New Campaign</a>
               </div>
            </div>
            <div className="row mt-3">
               <div className="col-12 p-0">
                  <div className="input-group">
                     <input type="text" className="form-control" placeholder="Search campaigns by name"/>
                     <div className="input-group-append">
                        <button className="btn btn-danger" type="button">
                        <i className="fa fa-search"></i>
                        </button>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <section className="campaign-sec-two">
         <div className="container-fluid">
         <div className="row">
            <div className="col-12 p-0">
               <div className="campaign-in">
                  <div className="row">
                     <div className="col-9 col-md-11 ">
                        <h4> Bluesg</h4>
                     </div>
                     <div className="col-3 col-md-1 ">
                        <a href="#" className="bt btn-md btn-red">Active</a>
                     </div>
                  </div>
                  <div className="row">
                     <div className="col-12">
                        <div className="bl-sec">
                           <ul>
                              <li><img src={"/images/ic01.png"}/>Sep 1, 2020 - sep 30, 2020</li>
                              <li><img src={"/images/ic02.png"}/>Tgere are no hashtags for this campaign!</li>
                              <li><img src={"/images/ic03.png"}/>There are no mentions for this capmpaign!</li>
                           </ul>
                        </div>
                     </div>
                  </div>
                  <div className="row">
                     <div className="col-12 text-center">
                        <a href="#" className="btn btn-lg btn-danger" data-toggle="modal" data-target="#exampleModalCenter">View Campaign</a>
                        
                     </div>
                  </div>
                  
               </div>
            </div>
         </div>
      </div></section>

      <section className="campaign-sec-two">
         <div className="container-fluid">
         <div className="row">
            <div className="col-12 p-0">
               <div className="campaign-in">
                  <div className="row">
                     <div className="col-9 col-md-11 ">
                        <h4> Bluesg</h4>
                     </div>
                     <div className="col-3 col-md-1 ">
                        <a href="#" className="bt btn-md btn-red">Active</a>
                     </div>
                  </div>
                  <div className="row">
                     <div className="col-12">
                        <div className="bl-sec">
                           <ul>
                              <li><img src={"/images/ic01.png"}/>Sep 1, 2020 - sep 30, 2020</li>
                              <li><img src={"/images/ic02.png"}/>Tgere are no hashtags for this campaign!</li>
                              <li><img src={"/images/ic03.png"}/>There are no mentions for this capmpaign!</li>
                           </ul>
                        </div>
                     </div>
                  </div>
                  <div className="row">
                     <div className="col-12 text-center">
                        <a href="#" className="btn btn-lg btn-danger" data-toggle="modal" data-target="#exampleModalCenter">View Campaign</a>
                        
                     </div>
                  </div>
                  
               </div>
            </div>
         </div>
      </div></section>

      <section className="campaign-sec-two">
         <div className="container-fluid">
         <div className="row">
            <div className="col-12 p-0">
               <div className="campaign-in">
                  <div className="row">
                     <div className="col-9 col-md-11 ">
                        <h4> Bluesg</h4>
                     </div>
                     <div className="col-3 col-md-1 ">
                        <a href="#" className="bt btn-md btn-red">Active</a>
                     </div>
                  </div>
                  <div className="row">
                     <div className="col-12">
                        <div className="bl-sec">
                           <ul>
                              <li><img src={"/images/ic01.png"}/>Sep 1, 2020 - sep 30, 2020</li>
                              <li><img src={"/images/ic02.png"}/>Tgere are no hashtags for this campaign!</li>
                              <li><img src={"/images/ic03.png"}/>There are no mentions for this capmpaign!</li>
                           </ul>
                        </div>
                     </div>
                  </div>
                  <div className="row">
                     <div className="col-12 text-center">
                        <a href="#" className="btn btn-lg btn-danger" data-toggle="modal" data-target="#exampleModalCenter">View Campaign</a>
                        
                     </div>
                  </div>
                  
               </div>
            </div>
         </div>
      </div></section>
        </>
    )
}
export default Campaign1;

import {useHistory} from 'react-router-dom';
import './style.css';
const Signup = () => {
    
    const history=useHistory();
    const signinHandler=()=>{
        history.push('/sign-in');
    }
    return (
        <>
            <header id="myHeader" className="header-bg2"></header>
            <div className="container">
                <div className="row">
                    <div className="col-12 col-md-12 col-sm-12 col-lg-12 mt-5 mb-2">
                        <div className="top-logo">
                            <img style={{ width: "20%", marginTop: "2em", marginBottom: "1em" }} src={"/images/thread-red-logo.png"} className="img-fluid" />
                        </div>
                    </div>
                    <div className="col-12 col-md-12 col-sm-12 col-lg-12">
                        <div className="text-danger mb-4">
                            <h2>Sign Up As</h2>
                        </div>
                    </div>
                </div>
                <div className="row">
                    <div className="col-12 col-md-12 col-sm-12 col-lg-12 mt-2">
                        <div className="in-text-sec">
                            <ul className="b">
                            <li><a href="" onClick={signinHandler}><img style={{width:"40px", height:"40px", marginRight:"15px"}} src={"/images/user-avatar.png"}/> Brand Manager</a></li>
                                <li><a href="" onClick={signinHandler}><img style={{width:"40px", height:"40px", marginRight:"15px"}} src={"/images/comapny.png"}/> Company</a></li>
                                <li><a href="" onClick={signinHandler}><img style={{width:"40px", height:"40px", marginRight:"15px"}} src={"/images/agency-logo.png"}/> Agency</a></li>
                            </ul>
                        </div>
                    </div>
              </div>
                            
                            <div className="row mb-5">
                                <div className="col-12 col-md-12 col-sm-12 col-lg-12 mt-4">
                                    <div className="privacy-link">
                                        <ul>
                                            <li><a href="#">Privacy Ploicy</a></li>
                        |
                        <li><a href="#">Terms &amp; Conditions</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
        </>
    )
}
export default Signup;
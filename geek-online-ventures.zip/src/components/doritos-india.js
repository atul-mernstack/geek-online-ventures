import './style.css';

const Doritos=()=>{
    return(

        <>
        <section className="doritos-sec">
         <div className="container-fluid">
            <div className="row">
               <div className="col-12 mt-3">
                  {/* <h2>Doritos India</h2> */}
                  <p>Tracking from Aug 28, 2020 to Sep 1,2020</p>
                  <p>#blameitoncrunch and @doritosindia</p>
               </div>
               <div className="col-12 mb-3 mt-5">
                  <div className="bl2-sec">
                     <ul>
                        <li>
                           <a href="#" className="btn btn-md btn-danger">Add Influencers</a>
                        </li>
                        <li>
                           <a href="#" className="btn btn-md btn-danger">Download</a>
                        </li>
                        <li>
                           <a href="#" className="btn btn-md btn-danger">Edit</a>
                        </li>
                        <li>
                           <a href="#" className="btn btn-md btn-danger"><i className="fa fa-trash" aria-hidden="true"></i></a>
                        </li>
                     </ul>
                  </div>
               </div>
               <div className="row mt-3">
                  <div className="col-12">
                     <div className="tt-sec">
                        <h3>Total Influencers
                        </h3>
                        <p>849 </p>
                     </div>
                     <div className="tt-sec">
                        <h3>Total Buget
                        </h3>
                        <p>$0</p>
                     </div>
                     <div className="tt-sec">
                        <h3>Total Posts
                        </h3>
                        <p>599 </p>
                     </div>
                     <div className="tt-sec">
                        <h3>Total Stories
                        </h3>
                        <p>640 </p>
                     </div>
                     <div className="tt-sec">
                        <h3>Total Engagement
                        </h3>
                        <p>3.7% 258.7K </p>
                     </div>
                     <div className="tt-sec">
                        <h3>Total Est.Reach
                        </h3>
                        <p>$ 171.103 </p>
                     </div>
                     <div className="tt-sec">
                        <h3>Total Est.Media Value
                        </h3>
                        <p>$ 171.1039 </p>
                     </div>
                  </div>
               </div>
            </div>
            <div className="row mt-5">
               <div className="col-12">
                  <img style={{width:"80%"}} src={"/images/influence-listimg.png"} className="img-fluid"/>
               </div>
            </div>
         </div>
      </section>
        </>
    )
}

export default Doritos;
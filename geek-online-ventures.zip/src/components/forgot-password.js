import { useEffect } from 'react';
import {useHistory} from 'react-router-dom';
import {Button} from 'reactstrap';
import './style.css';

const ForgotPassword=(props)=>{
const history=useHistory();
    useEffect(()=>{
        props.setFlag(false);
    },[]);
    const PasswordHandler=()=>{
        props.setFlag(true);
        history.push('/iphone_x');
    }
    return(
        <>
        <header id="myHeader" className="header-bg2"></header>
            <div className="container">
                <div className="row">
                    <div className="col-12 col-md-12 col-sm-12 col-lg-12 mt-5 mb-2">
                        <div className="top-logo">
                            <img style={{ width: "20%", marginTop: "2em", marginBottom: "1em" }} src={"/images/thread-red-logo.png"} alt="" className="img-fluid" />
                        </div>
                    </div>
                    <div className="col-12 col-md-12 col-sm-12 col-lg-12">
                        <div className="text-danger mb-4">
                            <h2 className="text-danger">Forgot Password?</h2>
                        </div>
                    </div>
                </div>
                <div className="row">
                    <div className="col-12 col-md-12 col-sm-12 col-lg-12 mt-1">
                        <div className="in-text-sec">
                            <form>
                                <div className="form-group">
                                    <input type="text" className="form-control u-name" id="Username" aria-describedby="Username" placeholder="Username or Email" />
                                </div>
                                <Button type="button" color="danger" size="lg"  style={{width:"40%", marginTop:"1em", marginBottom:"1em", borderRadius:"15px"}} 
                                onClick={PasswordHandler}>Get New Password</Button>
                                <div className="clearfix"></div>
                                {/* <a href="forgot-password.html"><small id="forgot-password"  className="form-text text-muted mt-3 mb-1 ">Forgot Password?</small></a> */}
                                {/* <a href="" onClick={PasswordHandler} id="forgot-password"  className="form-text text-muted mt-0 mb-3 ">Forgot Password?</a> */}
                            </form>
                        </div>
                    </div>
                </div>                
                <div className="row mb-5">
                    <div className="col-12 col-md-12 col-sm-12 col-lg-12 mt-5">
                         <div className="privacy-link">
                            <ul>
                                <li><a href="#">Privacy Ploicy</a></li>
                        |
                        <li><a href="#">Terms &amp; Conditions</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default ForgotPassword;
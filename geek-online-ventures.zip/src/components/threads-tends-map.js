import './style.css';

const TendsMap=()=>{
    return(
        <>
            <section className="threads-trens-sec">
         <div className="container-fluid">
            <div className="row">
               <div className="col-12 mt-5">
                  <div className="form-group">
                     <select className="form-control" id="Brands">
                        <option>Influncers Trends During Last Week</option>
                        <option>Influncers Trends During Last Week</option>
                        <option>Influncers Trends During Last Week</option>
                        <option>Influncers Trends During Last Week</option>
                        <option>Influncers Trends During Last Week</option>
                     </select>
                  </div>
               </div>
            </div>
            <div className="row">
               <div className="col-12 ">
                  <div className="heading-secin">
                     <h3>Most Active Brands</h3>
                  </div>
               </div>
               <a href="threads-tends-engagment.html">
                  <div className="col-12 mt-3">
                     <img style={{width:"100%", height:"300px"}} src={"/images/graph02.png"} alt="" className="img-fluid"/>
                  </div>
               </a>
            </div>
         </div>
      </section>
        </>
    )
}

export default TendsMap;
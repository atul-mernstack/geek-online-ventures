import {Button} from 'reactstrap';
import Carousel from "react-elastic-carousel";
import Campaigns from "./Campaigns";
import BrondAmbassadors from './Brand-ambassador';
import TopFans from './Top-fans';
import {Link,useHistory} from 'react-router-dom';

import './style.css';

const Iphone=()=>{
  const history=useHistory();
  const BriefFormHandle=()=>{
    history.push('/campaign-brief-form');
  }
    return(
        <>
    <section className="iphonex-sec-top">
         <div className="fill-bg">
         {/* <img style={{width:"100%"}} src={'/images/banner02.png'}/> */}
         </div>
         <div className="container-fluid text-center">
            <div className="row">
               <div className="col-4 pr-0">
                  <div className="social-icons mt-3">
                     <ul>
                        <li><Link to="/linkaccount"><img src={"/images/fb.png"} className="img-fluid mr-2"/></Link></li>
                        <li><Link to="/linkaccount"><img src={"/images/twitter.png"} className="img-fluid mr-2"/></Link></li>
                        <li><Link to="/linkaccount"><img src={"/images/insta.png"} className="img-fluid mr-2"/></Link></li>
                        <li><Link to="/linkaccount"><img src={"/images/pepsi.png"} className="img-fluid"/></Link></li>
                     </ul>
                  </div>
               </div>
               <div className="col-3 p-0 ">
                  <div className="lays-logo">
                     <a href="#"><img src={"/images/Lays-Logo.png"}/></a>
                  </div>
               </div>
               <div className="col-5 mt-3">
                  <ul>
                     <li><Button type="button" onClick={BriefFormHandle} size="sm" style={{borderRadius:"15px", backgroundColor:"red", marginRight:"2px"}}>Create Campaign</Button></li>
                     <li>
                        
                        <Link to="/additional-filter"><img src={"/images/search.png"} className="searchic"/></Link>
                        
                     </li>
                  </ul>
               </div>
            </div>
         </div>
      </section>
      <div className="mb-5">
      <h3 style={{ textAlign: "center", marginTop:"30px" }}>CAMPAIGNS</h3>
      <Campaign/>
      <h3 style={{ textAlign: "center", marginTop:"30px" }}>BRAND AMBASSADORS</h3>
      <BrondAmbassador/>
      <h3 style={{ textAlign: "center", marginTop:"30px" }}>TOP FANS</h3>
      <TopFan/>
      </div>
        </>
    )
}

const breakPoints = [
   { width: 1, itemsToShow: 1 },
   { width: 550, itemsToShow: 2 },
   { width: 768, itemsToShow: 3 },
   { width: 1200, itemsToShow: 4 },
 ];
 
 function Campaign() {
   return (
     <>
       {/* <h1 style={{ textAlign: "center" }}>carousel in react</h1> */}
       <div className="Slider">
         <Carousel breakPoints={breakPoints}>
           <Campaigns><Link to="/brief-page"><img style={{width:"100%", height:"250px"}} src={'/images/images-2.jpeg'} alt=""/><p >Heartwork</p></Link></Campaigns>
           <Campaigns><Link to="/brief-page"><img style={{width:"100%", height:"250px"}} src={'/images/0_h3JvwT-5KaAyVqNG.jpg'} alt=""/><p >Heartwork</p></Link></Campaigns>
           <Campaigns><Link to="/brief-page"><img style={{width:"100%", height:"250px"}} src={'/images/74031398.jpg'} alt=""/><p >Heartwork</p></Link></Campaigns>
           <Campaigns><Link to="/brief-page"><img style={{width:"100%", height:"250px"}} src={'/images/c2.jpg'} alt=""/><p >Heartwork</p></Link></Campaigns>
         </Carousel>
       </div>
     </>
   );
 }

 function BrondAmbassador() {
   return (
     <>
       <div className="Slider">
         <Carousel breakPoints={breakPoints}>
         <BrondAmbassadors><Link to="#"><img style={{width:"100%", height:"250px", marginTop:"50px", borderRadius:"200px"}} src={'/images/Alia_Bhatt_promoting_Kalank.jpg'} alt=""/><p >Name</p></Link></BrondAmbassadors>
           <BrondAmbassadors><Link to="#"><img style={{width:"100%", height:"250px", marginTop:"50px", borderRadius:"200px"}} src={'/images/74031398.jpg'} alt=""/><p >Name</p></Link></BrondAmbassadors>
           <BrondAmbassadors><Link to="#"><img style={{width:"100%", height:"250px", marginTop:"50px", borderRadius:"200px"}} src={'/images/Ranbir.jpg'} alt=""/><p >Name</p></Link></BrondAmbassadors>
           <BrondAmbassadors><Link to="#"><img style={{width:"100%", height:"250px", marginTop:"50px", borderRadius:"200px"}} src={'/images/c3.jpg'} alt=""/><p >Name</p></Link></BrondAmbassadors>
         </Carousel>
       </div>
     </>
   );
 }

 function TopFan() {
   return (
     <>
       <div className="Slider">
         <Carousel breakPoints={breakPoints}>
         <TopFans><Link to="#"><img style={{width:"100%", height:"250px", marginTop:"50px", borderRadius:"200px"}} src={'/images/Alia_Bhatt_promoting_Kalank.jpg'} alt=""/><p >Name</p></Link></TopFans>
           <TopFans><Link to="#"><img style={{width:"100%", height:"250px", marginTop:"50px", borderRadius:"200px"}} src={'/images/74031398.jpg'} alt=""/><p >Name</p></Link></TopFans>
           <TopFans><Link to="#"><img style={{width:"100%", height:"250px", marginTop:"50px", borderRadius:"200px"}} src={'/images/Ranbir.jpg'} alt=""/><p >Name</p></Link></TopFans>
           <TopFans><Link to="#"><img style={{width:"100%", height:"250px", marginTop:"50px", borderRadius:"200px"}} src={'/images/c3.jpg'} alt=""/><p >Name</p></Link></TopFans>
         </Carousel>
       </div>
     </>
   );
 }

export default Iphone;
import './style.css';
 
const InfluencerList=()=>{
    return(
        <>
        <div className="container mt-5">
            <div className="row text-center">
                <div className="col-12">
                    <div>
                        <img style={{width:"80%"}} src={'/images/influence-listimg.png'} alt="" />
                    </div>
                </div>
            </div>
        </div>
        </>
    )
}

export default InfluencerList;
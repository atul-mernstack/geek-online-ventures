import './style.css';
const SmeSpecial=()=>{
    return(
        <>
        <section className="pro-plan-secin">
         <div className="container">
            <div className="row">
               <div className="col-12 col-md-12 col-sm-12 col-lg-12">
                  <div className="heading-sec">
                     <h2 className="text-danger">SME SPECIAL</h2>
                  </div>
               </div>
            </div>
            <div className="row">
               <div className="col-12 col-md-12 col-sm-12 col-lg-12 mt-2">
               <ul className="b text-left h4">
                     <li><a href="#">1 Account </a></li>
                     <li><a href="#">Limited advanced discovery searches</a></li>
                     <li><a href="#">50 Influencer analytics/ mo </a></li>
                     <li><a href="#">1 Active Campaign</a></li>
                     <li><a href="#">FB, YT &amp; TikTok Channel Access </a></li>
                     <li><a href="#">Data Export as CSV &amp; Powerpoint </a></li>
                     <li><a href="#">Influencer CRM </a></li>
                     <li><a href="#">Story Tracking </a></li>
                     <li><a href="#">API Access </a></li>
                     <li><a href="#">Dedicated Account Manager</a></li>
                  </ul>
               </div>
            </div>
            <div className="row">
               <div className="col-12 col-md-12 col-sm-12 col-lg-12 mt-2 mb-2 text-center">
                  <button type="button" className="btn btn-lg btn-light">CONTACT US</button>
               </div>
            </div>
            <div className="row">
               <div className="col-12 col-md-12 col-sm-12 col-lg-12 text-center">
                  <div className="privacy-btns">
                     <ul>
                        {/* <li><a href="#">Privacy Ploicy</a></li>
                        | 
                        <li><a href="#">Terms &amp; Conditions</a></li> */}
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </section>
        </>
    )
}
export default SmeSpecial;
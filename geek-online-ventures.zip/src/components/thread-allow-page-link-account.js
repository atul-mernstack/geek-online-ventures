import {Link} from "react-router-dom";
import './style.css';

const ThreadAllowPage=()=>{
    return(

        <>
<section className="manage-profile-sec">
         <div className="container">
            <div className="row">
               <div className="col-12 col-md-12 col-sm-12 col-lg-12">
                  <div className="heading-sec">
                     <h2 className="text-danger">Link Account</h2>
                  </div>
               </div>
            </div>
            <div className="row">
               <div className="col-12 col-md-12 col-sm-12 col-lg-12 mt-2">
                  <div className="in-text-sec">
                     <ul className="b">
                        <li><Link to="/sme-plan">SME</Link></li>
                        <li><Link to="/sme-special">SME SPECIAL</Link></li>
                        <li><Link to="/price-pro-plan">PRO PLAN </Link></li>
                        <li><Link to="/enterprise">ENTERPRISE</Link></li>
                     </ul>
                  </div>
               </div>
            </div>
            <div className="row">
               <div className="col-12 col-md-12 col-sm-12 col-lg-12 mt-2 mb-2 text-center">
                  <button type="button" className="btn btn-lg btn-light ">CONTACT US</button>
               </div>
            </div>
            <div className="row">
               <div className="col-12 col-md-12 col-sm-12 col-lg-12 text-center">
                  <div className="privacy-btns">
                     <ul>
                        
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </section>
        </>
    )
}
export default ThreadAllowPage;
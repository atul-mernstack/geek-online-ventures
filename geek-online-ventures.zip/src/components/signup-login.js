import { useHistory } from 'react-router-dom';
import {Button} from 'reactstrap';
import './style.css';
const SignupLogin=()=>{
    const history=useHistory();
    const signupHandler=()=>{
        history.push('/sign-up');
    }

    const signinHandler=()=>{
        history.push('/sign-in');
    }
    return(
        <div className="threds_signup-login_bg">
        <div className="container">
            <div className="row">
               <div className="col-12 col-md-12 col-sm-12 col-lg-12 ">
                  <div className="thread-white-logo">
                     <img style={{width:"20%", marginTop:"5em"}} src={"images/threads-white-logo.png"} className="img-fluid"/>
                  </div>
               </div>
            </div>
            <div className="row">
               <div className="col-12 col-md-12 col-sm-12 col-lg-12">
                  <div className="sl-btns">
                     <Button type="button" className="btn btn-lg btn-light"  onClick={signinHandler} style={{width:"30%", marginTop:"10em", borderRadius:"15px"}}>Login</Button>
                     <br></br>
                     <Button type="button" className="btn btn-lg btn-light" onClick={signupHandler} style={{width:"30%", marginTop:"1em", marginBottom:"2em", borderRadius:"15px"}}>Sign up</Button>
                  </div>
               </div>
            </div>
         </div>
        </div>
    )
}
export default SignupLogin;
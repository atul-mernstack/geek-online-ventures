import './style.css';

const CampaignBriefForm=()=>{
    return(

        <>
<section className="campaign-sec-two mt-5">
         <div className="container-fluid mt-2">
         <div className="row">
            <div className="col-12">
               <div className="heading-sec">
                  <h2 className="text-danger">Campaign Brief Form</h2>
               </div>
            </div>
         </div>
         <div className="row">
            <div className="col-12">
               <form>
                  <div className="form-group">
                     <label for="nameofthecampaign">Name of the  campaign</label>
                     <input type="text" className="form-control" id="nameofthecampaign" aria-describedby="nameofthecampaign"/>
                  </div>
                  <div className="form-group">
                     <label for="Hashtag">Hashtag</label>
                     <input type="text" className="form-control" id="Hashtag" aria-describedby="Hashtag"/>
                  </div>
                  <div className="form-group">
                     <label for="Hashtag">Brief</label>
                     <input type="text" className="form-control" id="Brief" aria-describedby="Brief"/>
                  </div>
                  <div className="form-group">
                     <div className="row">
                        <div className="col-6">
                           <label for="Hashtag">Minimum Followers</label>
                           <select className="form-control" id="exampleFormControlSelect1">
                              <option>Facebook</option>
                              <option>Twitter</option>
                              <option>Google Plus</option>
                              <option>Linkedin</option>
                              <option>Instagram</option>
                           </select>
                        </div>
                        <div className="col-6">
                           <label for="Hashtag">Type</label>
                           <select className="form-control" id="exampleFormControlSelect1">
                              <option>Facebook</option>
                              <option>Twitter</option>
                              <option>Google Plus</option>
                              <option>Linkedin</option>
                              <option>Instagram</option>
                           </select>
                        </div>
                     </div>
                  </div>
                  <div className="form-group">
                     <div className="row">
                        <div className="col-6">
                           <label for="from">From</label>
                           <div className="input-group date" id="datetimepicker1">
                              <input id="datepicker" width="100%" className="form-control hasDatepicker"/>
                              <span className="input-group-addon">
                              <i className="fa fa-calendar-o" aria-hidden="true"></i>
                              </span>
                           </div>
                        </div>
                        <div className="col-6">
                           <label for="to">To</label>
                           <div className="input-group date" id="datetimepicker2">
                              <input id="datepicker2" width="100%" className="form-control hasDatepicker"/>
                              <span className="input-group-addon">
                              <i className="fa fa-calendar-o" aria-hidden="true"></i>
                              </span>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div className="form-group">
                     <label for="post-video">Post or Video</label>
                     <input type="text" className="form-control" id="post-video" aria-describedby="post-video" placeholder="Mention type &amp; number of posts"/>
                  </div>
                  <div className="form-group">
                     <label for="special-req">Special Requirements</label>
                     <textarea className="form-control" rows="5" id="special-req"></textarea>
                  </div>
               </form>
               <div className="form-group">
                  <div className="r-btns">
                     <ul>
                        <li><a href="#" className="btn bnt-md btn-red">Reset</a></li>
                        <li><a href="thankyou.html" className="btn bnt-md btn-red">Submit</a></li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </div></section>
        </>
    )
}

export default CampaignBriefForm;
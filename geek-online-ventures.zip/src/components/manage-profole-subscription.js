import {Link} from 'react-router-dom';
import './style.css';

const ManageProfole=()=>{
    return(
        <>
<section className="manage-profile-sec">
         <div className="container">
            <div className="row">
               <div className="col-12 col-md-12 col-sm-12 col-lg-12">
                  <div className="heading-sec">
                     <h5 className="text-danger">Manage Profile &amp; Subscription</h5>
                     <h6>Affordable pricing for companies of all sizes</h6>
                  </div>
               </div>
            </div>
            <div className="row">
               <div className="col-12 col-md-12 col-sm-12 col-lg-12 mt-2">
                  <div className="in-text-sec">
                     <ul className="b">
                        <li><Link to="/sme-plan">SME</Link></li>
                        <li><Link to="/sme-special">SME SPECIAL</Link></li>
                        <li><Link to="/price-pro-plan">PRO PLAN </Link></li>
                        <li><Link to="/enterprise">ENTERPRISE</Link></li>
                     </ul>
                  </div>
               </div>
            </div>
            <div className="row">
               <div className="col-12 col-md-12 col-sm-12 col-lg-12 mt-2 mb-2 text-center">
                  <button type="button" className="btn btn-lg btn-light ">CONTACT US</button>
               </div>
            </div>
            <div className="row">
               <div className="col-12 col-md-12 col-sm-12 col-lg-12">
                  <div className="privacy-btns  text-center">
                     <ul>
                        {/* <li><a href="#">Privacy Ploicy</a></li>
                        | 
                        <li><a href="#">Terms &amp; Conditions</a></li> */}
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </section>
        </>
    )
}
export default ManageProfole;
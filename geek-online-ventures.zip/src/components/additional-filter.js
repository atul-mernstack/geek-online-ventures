import React, { useState } from 'react';
import {Link} from 'react-router-dom';
import { TabContent, TabPane, Nav, NavItem, NavLink,Button,Row, Col } from 'reactstrap';
import { Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';
import classnames from 'classnames';
import './style.css';

const AdditionalFilter = (props) => {
   const {className } = props;
   const [modal, setModal] = useState(false);
   const toggle = () => setModal(!modal);


   const [activeTab, setActiveTab] = useState('1');
   const togglet = tab => {
      if (activeTab !== tab) setActiveTab(tab);
   }
   return (
      <div className="mt-4">
         <Nav tabs >
            <NavItem >
               <NavLink className={classnames({ active: activeTab === '1' })} onClick={() => { togglet('1'); }} className="text-dark"
                  style={{ backgroundColor: "#dd2d37", width: "130px" }}
               >
                  Influencer
          </NavLink>
            </NavItem>
            <NavItem>
               <NavLink
                  className={classnames({ active: activeTab === '2' })}
                  onClick={() => { togglet('2'); }}
                  className="text-dark"
                  style={{ backgroundColor: "#dd2d37", width: "130px" }}
               >
                  Audience
          </NavLink>
            </NavItem>
            <NavItem>
               <NavLink
                  className={classnames({ active: activeTab === '3' })}
                  onClick={() => { togglet('3'); }}
                  className="text-dark"
                  style={{ backgroundColor: "#dd2d37", width: "130px" }}
               >
                  Group
          </NavLink>
            </NavItem>
         </Nav>
         <TabContent activeTab={activeTab}>
            <TabPane tabId="1">
               <Row>
                  <Col sm="12">
                     <section className="filter-sec-two mt-3">
                        <div className="container-fluid mb-4">
                           <div className="row">
                              <div className="col-12">
                                 <form>
                                    <div className="form-group">
                                       <input type="text" className="form-control" id="searchbyname" aria-describedby="searchbyname" placeholder="Search by name/ handle" />
                                    </div>
                                    <div className="form-group radiored-btn text-left">
                                       <label htmlFor="Gender">Gender</label><br></br>
                                       <div className="row">
                                          <div className="col-4">
                                             <label className="radio-inline">
                                                <input type="radio" name="optradio" /> Male
                                 </label>
                                          </div>
                                          <div className="col-6">
                                             <label className="radio-inline">
                                                <input type="radio" name="optradio" /> Female
                                 </label>
                                          </div>
                                       </div>
                                    </div>
                                    <div className="form-group text-left">
                                       <label htmlFor="Interests">Interests</label>
                                       <input type="text" className="form-control" id="Brief" aria-describedby="Interests" placeholder="Eg. Travel, Food, Fitness etc." />
                                    </div>
                                    <div className="form-group text-left">
                                       <label htmlFor="Brands2">Brands</label>
                                       <input type="text" className="form-control" id="Brands2" aria-describedby="Brands2" placeholder="Eg. Pepsi, Samsung, Slic etc." />
                                    </div>
                                    <div className="form-group text-left">
                                       <label htmlFor="Brands3">Location ( Country or City )</label>
                                       <select className="form-control" id="Brands3">
                                          <option>India</option>
                                          <option>USA</option>
                                          <option>UK</option>
                                          <option>Africa</option>
                                          <option>UAE</option>
                                       </select>
                                    </div>
                                    <div className="form-group">
                                       <div className="row">
                                          <div className="col-6 text-left">
                                             <label htmlFor="Hashtag">Followers</label>
                                             <select className="form-control" id="exampleFormControlSelect1">
                                                <option>100 Followers</option>
                                                <option>200 Followers</option>
                                                <option>300 Followers</option>
                                                <option>400 Followers</option>
                                                <option>500 Followers</option>
                                             </select>
                                          </div>
                                          <div className="col-6">
                                             <label htmlFor="Hashtag">&nbsp;</label>
                                             <select className="form-control" id="exampleFormControlSelect2">
                                                <option>100 Followers</option>
                                                <option>200 Followers</option>
                                                <option>300 Followers</option>
                                                <option>400 Followers</option>
                                                <option>500 Followers</option>
                                             </select>
                                          </div>
                                       </div>
                                    </div>
                                 </form>
                                 <div id="accordion" className="accordion">
                                    <div className="card mb-0">
                                       <div className="card-header collapsed" data-toggle="collapse" href="#collapseOne">
                                          <a className="card-title" style={{ textDecoration: "none" }}>
                                             Additional Filter
                              </a>
                                       </div>
                                       <div id="collapseOne" className="card-body collapse" data-parent="#accordion">
                                          <h4>Subscription followers</h4>
                                          <p>Include only influencers up to this threshold</p>
                                          <div className="range-wrap">
                                             <div className="range-value" id="rangeV"></div>
                                             <input id="range" type="range" min="1" max="100" value="2" step="1" />
                                          </div>
                                    
                                          <div className="form-check">
                                             <label className="form-check-label">
                                                <input type="checkbox" className="form-check-input" value="" />Contract info Available
                                 </label>
                                          </div>
                                          <div className="form-check">
                                             <label className="form-check-label">
                                                <input type="checkbox" className="form-check-input" value="" />Specific Time Period
                                 </label>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div className="col-12  mt-5 mb-3 st-txt">
                                 <h4 className="text-left">Sort By</h4>
                                 <div className="btn-group text-center" role="group" aria-label="Basic example">
                                    <button type="button" className="btn btn-light active">Relevance </button>
                                    <button type="button" className="btn btn-light">Followers </button>
                                    <button type="button" className="btn btn-light">Engagement </button>
                                 </div>
                              </div>
                              <div className="col-12   mb-5">
                                 <div className="r-btns">
                                    <ul >
                                       <li><Link to="/influencers-discovery" className="btn bnt-md btn-red active">Search</Link></li>
                                       <li><Link to="#" className="btn bnt-md btn-red">Reset</Link></li>
                                    </ul>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </section>
                  </Col>
               </Row>
            </TabPane>
            <TabPane tabId="2">
               <Row>
                  <Col sm="12">
                     <section className="filter-sec-two mt-3">
                        <div className="container-fluid mb-4">
                           <div className="row">
                              <div className="col-12">
                                 <form>
                                    <div className="form-group text-left">
                                       <label htmlFor="Gender">Age Ranges</label><br></br>
                                       <div className="form-check form-check-inline col-3">
                                          <input className="form-check-input" type="checkbox" id="inlineCheckbox1" value="option1" />
                                          <label className="form-check-label" htmlFor="inlineCheckbox1">0 - 18</label>
                                       </div>
                                       <div className="form-check form-check-inline col-3">
                                          <input className="form-check-input" type="checkbox" id="inlineCheckbox2" value="option2" />
                                          <label className="form-check-label" htmlFor="inlineCheckbox2">19-25</label>
                                       </div>
                                       <div className="form-check form-check-inline col-3">
                                          <input className="form-check-input" type="checkbox" id="inlineCheckbox3" value="option3" />
                                          <label className="form-check-label" htmlFor="inlineCheckbox3">26-32</label>
                                       </div>
                                       <br></br>
                                       <div className="form-check form-check-inline col-3">
                                          <input className="form-check-input" type="checkbox" id="inlineCheckbox4" value="option4" />
                                          <label className="form-check-label" htmlFor="inlineCheckbox4">33-39</label>
                                       </div>
                                       <div className="form-check form-check-inline col-3">
                                          <input className="form-check-input" type="checkbox" id="inlineCheckbox5" value="option5" />
                                          <label className="form-check-label" htmlFor="inlineCheckbox5">40-46</label>
                                       </div>
                                       <div className="form-check form-check-inline col-3">
                                          <input className="form-check-input" type="checkbox" id="inlineCheckbox6" value="option6" />
                                          <label className="form-check-label" htmlFor="inlineCheckbox5">46+</label>
                                       </div>
                                    </div>
                                    <div className="form-group radiored-btn text-left">
                                       <label htmlFor="Gender">Gender</label><br></br>
                                       <div className="row">
                                          <div className="col-4">
                                             <label className="radio-inline">
                                                <input type="radio" name="optradio" /> Male
                                 </label>
                                          </div>
                                          <div className="col-6">
                                             <label className="radio-inline">
                                                <input type="radio" name="optradio" /> Female
                                 </label>
                                          </div>
                                       </div>
                                    </div>
                                    <div className="form-group text-left">
                                       <label htmlFor="Interests">Interests</label>
                                       <input type="text" className="form-control" id="brief" aria-describedby="Interests" placeholder="Eg. Travel, Food, Fitness etc." />
                                    </div>
                                    <div className="form-group text-left">
                                       <label htmlFor="Brands">Countries</label>
                                       <select className="form-control" id="Brands">
                                          <option>India</option>
                                          <option>USA</option>
                                          <option>UK</option>
                                          <option>Africa</option>
                                          <option>UAE</option>
                                       </select>
                                    </div>
                                 </form>
                              </div>
                              <div className="col-12  mt-3 mb-3 st-txt">
                                 <h4>Sort By</h4>
                                 <div className="btn-group text-center" role="group" aria-label="Basic example">
                                    <button type="button" className="btn btn-light ">Relevance</button>
                                    <button type="button" className="btn btn-light">Followers</button>
                                    <button type="button" className="btn btn-light">Engagement</button>
                                 </div>
                              </div>
                              <div className="col-12   mb-2">
                                 <div className="r-btns">
                                    <ul>
                                       <li><Link to="#" className="btn bnt-md btn-red active">Search</Link></li>
                                       <li><Link to="#" className="btn bnt-md btn-red">Reset</Link></li>
                                    </ul>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </section>
                  </Col>
               </Row>
            </TabPane>
            <TabPane tabId="3">
               <Row>
                  <Col sm="12">
                     <section className="filter-sec-two mt-3">
                        <div className="container-fluid mb-4">
                           <div className="tab-pane  group-sec" id="group">
                              <div className="row">
                                 <div className="col-12">
                                    <ul>
                                       {/* <li><a href="#" data-toggle="modal" data-target="#exampleModalCenter">Create Group <span>+</span> </a></li> */}

                                       <li><a href="#" onClick={toggle}>Create Group <span>+</span> </a></li>
                                    </ul>
                                 </div>
                              </div>
                           </div>
                           {/* Modals */}
                           {/* <Button color="danger" onClick={togglem}>{buttonLabel}</Button> */}
                           <Modal isOpen={modal} toggle={toggle} className={className}>
                              <ModalHeader toggle={toggle}>Create Group</ModalHeader>
                              <ModalBody>
                                 <div className="form-group">
                                    <input type="text" style={{borderBlockColor:"red", height:"50px"}} className="form-control" id="text" placeholder="Enter Group Name" />
                                 </div>
                              </ModalBody>
                              <ModalFooter>
                                 <Button color="danger" onClick={toggle}>Create Group</Button>{' '}

                              </ModalFooter>
                           </Modal>
                        </div>
                     </section>
                  </Col>
               </Row>
            </TabPane>
         </TabContent>
      </div>
   )
}
export default AdditionalFilter;
import './style.css';

const LinkAccount=()=>{
    return(
        <>
<section className="link-account">
         <div className="container">
            <div className="row">
               <div className="col-12 col-md-12 col-sm-12 col-lg-12">
                  <div className="heading-sec">
                     <h2 className="text-danger">Link Accounts</h2>
                  </div>
               </div>
            </div>
            <div className="row">
               <div className="col-12 col-md-12 col-sm-12 col-lg-12 mt-2">
                  <div className="in-text-sec">
                     <ul className="b">
                        <li>
                           <div className="form-group">
                              <label for="usr">Instagram:</label>
                              <input type="text" className="form-control" id="Instagram" placeholder="Number of Followers"/>
                           </div>
                        </li>
                        <li>
                           <div className="form-group">
                              <label for="usr">Facebook:</label>
                              <input type="text" className="form-control" id="Facebook" placeholder="Number of Likes"/>
                           </div>
                        </li>
                        <li>
                           <div className="form-group">
                              <label for="usr">Tiktok:</label>
                              <input type="text" className="form-control" id="Tiktok" placeholder="Number of Followers"/>
                           </div>
                        </li>
                        <li>
                           <div className="form-group">
                              <label for="usr">Youtube:</label>
                              <input type="text" className="form-control" id="Youtube" placeholder="Number of Subscribers"/>
                           </div>
                        </li>
                        <li>
                           <div className="form-group">
                              <label for="usr">Twitter:</label>
                              <input type="text" className="form-control" id="Twitter" placeholder="Number of Followers"/>
                           </div>
                        </li>
                        <li>
                           <div className="form-group">
                              <label for="usr">Website:</label>
                              <input type="text" className="form-control" id="Website" placeholder="Number of Followers"/>
                           </div>
                        </li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </section>
        </>
    )
}
export default LinkAccount;
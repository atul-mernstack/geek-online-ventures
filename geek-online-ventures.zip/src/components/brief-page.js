import {Button} from 'reactstrap';

import {useHistory} from 'react-router-dom';
import './style.css';

const Brief=()=>{
    const history=useHistory();
    const InfluencerHandle=()=>{
        history.push('/influencers-list');
    }
    const PostHandle=()=>{
        history.push('/posts');
    }
    const ReportHandle=()=>{
        history.push('/report-page');
    }
    return(
        <>
        <div className="container mt-5 mb-5">
            <div className="row">
                <div className="col-12">
                    <img style={{width:"100%", height:"350px", marginBottom:"15px"}} src={'/images/images-2.jpeg'} alt=""/>
                </div>
                <span style={{fontWeight:"bold", fontSize:"20px", marginLeft:"15px"}}>Brief</span>
                <span style={{alignContent:"end"}}></span>
            </div>
            <div className="row">
                <div className="col-12 text-left">
                    <p>orem Ipsum is simply dummy text of the printing and typesetting industry.specimen book. It has survived not<br></br><br></br>

orem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not</p>
                </div>
            </div>
            <div className="row">
                <div className="col-12">
                <Button color="danger" onClick={InfluencerHandle} type="button" style={{marginRight:"5px"}}>Influncers</Button>
                <Button color="danger" onClick={PostHandle} type="button" style={{marginRight:"5px"}}>Posts</Button>
                <Button color="danger" onClick={ReportHandle} type="button">Export Report</Button>
                </div>
            </div>
        </div>
        </>
    )
}
export default Brief;
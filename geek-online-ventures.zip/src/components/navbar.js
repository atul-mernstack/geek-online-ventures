import React, { useState } from 'react';
import { Route } from 'react-router-dom';
import Iphone from './iphone_x';
import Brief from './brief-page';
import InfluencerList from './influencers-list';
import Post from './posts';
import Report from './report-page';
import Trend from './trend-dashboard';
import TendsMap from './threads-tends-map';
import Campaign1 from './campaign1';
import Doritos from './doritos-india';
import AdditionalFilter from './additional-filter';
import ContentFilter from './content-filter';
import Category from './category';
import InfluencerDiscovery from './Influencers-discovery';
import ManageProfole from './manage-profole-subscription';
import ThreadAllowPage from './thread-allow-page-link-account';
import CampaignBriefForm from './campaign-brief-form';
import { Link } from 'react-router-dom';
import { Navbar,NavbarBrand, NavItem} from 'reactstrap';
import { UncontrolledDropdown, DropdownToggle, DropdownMenu, DropdownItem, Button } from 'reactstrap';
import { ButtonDropdown } from 'reactstrap';
import './style.css';
import Enterprice from './enterprice';
import SmePlan from './sme-plan';
import SmeSpecial from './sme-special';
import PriceProPlan from './price-pro-plan';
import LinkAccount from './linkaccount';
import { Switch} from 'react-router-dom';
const Navbar1 = () => {
  
  const [isOpen, setIsOpen] = useState(false);
  const toggle0 = () => setIsOpen(!isOpen);

  const [dropdownOpen, setOpen] = useState(false);
  const toggle = () => setOpen(!dropdownOpen);

  const [dropdownOpen1, setOpen1] = useState(false);
  const toggle1 = () => setOpen1(!dropdownOpen1);

  const [dropdownOpen2, setOpen2] = useState(false);
  const toggle2 = () => setOpen2(!dropdownOpen2);

  const [dropdownOpen3, setOpen3] = useState(false);
  const toggle3 = () => setOpen3(!dropdownOpen3);

  return (
    <>
      <header id="myHeader" className="header-bg sticky">
        {/* <div className="bottom-header"> */}
        <div className="container">
           <Navbar color="faded" light expand="md">
              <NavbarBrand href="/" className="mr-auto"><img src={"/images/threads-white-logo.png"} alt="Logo" style={{ maxHeight: "50px" }} /></NavbarBrand>

              <UncontrolledDropdown className="ml-auto">
                <DropdownToggle nav >
                  <Button color="light">
                    <i className="fa fa-bars" style={{ backgroundColor: "faded" }}></i>
                  </Button>

                </DropdownToggle>
                <DropdownMenu right>
                  <DropdownItem>
                  <Link className="text-dark h6 m-2" style={{textDecoration:"none"}} to="/category">Profile</Link>
                  </DropdownItem>
                  <DropdownItem divider />
                  <DropdownItem>
                  <Link className="text-dark h6 m-2" style={{textDecoration:"none"}} to="/campaigns">Campains</Link>
                  </DropdownItem>
                  <DropdownItem divider />
                  <DropdownItem>
                  <Link className="text-dark h6 m-2" style={{textDecoration:"none"}} to="/influencers-discovery">Influency Discovery</Link>
                  </DropdownItem>
                  <DropdownItem divider />
                  <DropdownItem>
                  <Link className="text-dark h6 m-2" style={{textDecoration:"none"}} to="/manage-profole-subscription">Brand Ambassador</Link>
                  </DropdownItem>
                  <DropdownItem divider />
                  <DropdownItem>
                  <Link className="text-dark h6 m-2" style={{textDecoration:"none"}} to="/trend-dashboard">Trends</Link>
                  </DropdownItem>
                  <DropdownItem divider />
                  <DropdownItem>
                  <Link className="text-dark h6 m-2" style={{textDecoration:"none"}} to="/report-page">Reports</Link>
                  </DropdownItem>
                  <DropdownItem divider />
                  <DropdownItem>
                  <Link className="text-dark h6 m-2" style={{textDecoration:"none"}} to="/thread-allow-page-link-account">Manage Subscription</Link>
                  </DropdownItem>
                </DropdownMenu>
              </UncontrolledDropdown>
            </Navbar>
        </div>
        
        <div className="menu-sec-top ">
          <div className="container">
            <div className="row ml-1">
              
              <ButtonDropdown isOpen={dropdownOpen} toggle={toggle} className="mr-1">
                <DropdownToggle caret color="light" size="sm">
                  Instagram
      </DropdownToggle>
                <DropdownMenu>
                  <DropdownItem><NavItem>
                    <Link to="#" className="text-dark h6 m-2" style={{textDecoration:"none"}}>Instagram</Link>
                  </NavItem></DropdownItem>
                  <DropdownItem divider />
                  <DropdownItem><NavItem>
                    <Link to="#" className="text-dark h6 m-2" style={{textDecoration:"none"}}>Facebook</Link>
                  </NavItem></DropdownItem>
                  <DropdownItem divider />
                  <DropdownItem><NavItem>
                    <Link to="#" className="text-dark h6 m-2" style={{textDecoration:"none"}}>WhatsApp</Link>
                  </NavItem></DropdownItem>
                  <DropdownItem divider />
                  <DropdownItem><NavItem>
                    <Link to="#" className="text-dark h6 m-2" style={{textDecoration:"none"}}>Youtube</Link>
                  </NavItem></DropdownItem>
                  <DropdownItem divider />
                  <DropdownItem><NavItem>
                    <Link to="#" className="text-dark h6 m-2" style={{textDecoration:"none"}}>Tiktok</Link>
                  </NavItem></DropdownItem>
                </DropdownMenu>
              </ButtonDropdown>

              <ButtonDropdown isOpen={dropdownOpen1} toggle={toggle1} className="mr-1">
                <DropdownToggle caret color="light" size="sm">
                  Discovery
      </DropdownToggle>
                <DropdownMenu>
                  <DropdownItem><NavItem>
                    <Link to="/additional-filter" className="text-dark h6 m-2" style={{textDecoration:"none"}}>Influencers</Link>
                  </NavItem></DropdownItem>
                  <DropdownItem divider />
                  <DropdownItem><NavItem>
                    <Link to="/content-filter" className="text-dark h6 m-2" style={{textDecoration:"none"}}>content Discovery</Link>
                  </NavItem></DropdownItem>
                </DropdownMenu>
              </ButtonDropdown>

              <ButtonDropdown isOpen={dropdownOpen2} toggle={toggle2} className="mr-1">
                <DropdownToggle caret color="light" size="sm">
                  Reports
      </DropdownToggle>
                <DropdownMenu>
                  <DropdownItem>
                    <Link to="/campaigns" className="text-dark h6 m-2" style={{textDecoration:"none"}}>Campaigns</Link>
                  </DropdownItem>
                  <DropdownItem divider />
                  <DropdownItem>
                    <Link to="/report-page" className="text-dark h6 m-2" style={{textDecoration:"none"}}>Campaign Reports</Link>
                  </DropdownItem>
                  <DropdownItem divider />
                  <DropdownItem>
                    <Link to="/doritos-india" className="text-dark h6 m-2" style={{textDecoration:"none"}}>Doritos India</Link>
                  </DropdownItem>
                </DropdownMenu>
              </ButtonDropdown>

              <ButtonDropdown isOpen={dropdownOpen3} toggle={toggle3}>
                <DropdownToggle caret color="light" size="sm">
                  Trends
      </DropdownToggle>
                <DropdownMenu>
                  <DropdownItem >
                    <Link to="/threads-tends-map" className="text-dark h6 m-2" style={{textDecoration:"none"}}>Market Trends</Link>
                  </DropdownItem>
                  <DropdownItem divider />
                  <DropdownItem >
                    <Link to="/trend-dashboard" className="text-dark h6 m-2" style={{textDecoration:"none"}}>Brand Comparison</Link>
                  </DropdownItem>
                </DropdownMenu>
              </ButtonDropdown>            
              <span className="mul">
                <Link to="/trend-dashboard"><img src={"/images/ar01.png"} className="img-fluid" /></Link>
                <Link to="/trend-dashboard"><img src={"/images/mail01.png"} className="img-fluid" /></Link>
              </span>              
            </div>
          </div>
        </div>
      </header>
      <div className="container mt-4">
        <div className="row">
          <div className="col-12 mr-auto">
            <Switch>
              <Route exact path="/iphone_x"><Iphone /></Route>
              <Route exact path="/category"><Category /></Route>
              <Route exact path="/campaigns"><Campaign1 /></Route>
              <Route exact path="/influencers-discovery"><InfluencerDiscovery /></Route>
              <Route exact path="/manage-profole-subscription"><ManageProfole /></Route>
              <Route exact path="/trend-dashboard"><Trend /></Route>
              <Route exact path="/linkaccount"><LinkAccount /></Route>
              <Route exact path="/additional-filter"><AdditionalFilter /></Route>
              <Route exact path="/content-filter"><ContentFilter /></Route>
              <Route exact path="/report-page"><Report /></Route>
              <Route exact path="/doritos-india"><Doritos /></Route>
              <Route exact path="/thread-allow-page-link-account"><ThreadAllowPage /></Route>
              <Route exact path="/threads-tends-map"><TendsMap /></Route>
              <Route exact path="/campaign-brief-form"><CampaignBriefForm /></Route>
              <Route exact path="/brief-page"><Brief /></Route>
              <Route exact path="/influencers-list"><InfluencerList /></Route>
              <Route exact path="/posts"><Post /></Route>
              <Route exact path="/sme-plan"><SmePlan /></Route>
              <Route exact path="/sme-special"><SmeSpecial /></Route>
              <Route exact path="/price-pro-plan"><PriceProPlan /></Route>
              <Route exact path="/enterprise"><Enterprice /></Route>
            </Switch>
          </div>
        </div>
      </div>
    </>
  )
}
export default Navbar1;


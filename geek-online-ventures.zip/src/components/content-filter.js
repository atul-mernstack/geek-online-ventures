import './style.css';

const ContentFilter = () => {
    return (
        <>
            <section className="trend-dashboard">
         <div className="container-fluid mt-2">
         <div className="row">
            <div className="col-12 ">
               <div className="heading-sec text-left">
                  <h4>Content Filter</h4>
               </div>
            </div>
         </div>
         <div className="row">
            <div className="col-12">
               <form>
                  <div className="form-group">
                     <label htmlFor="influencer-group">Influencer or Group</label>
                     <input type="text" className="form-control" id="influencer-group" aria-describedby="influencer-group"/>
                  </div>
                  <div className="form-group">
                     <label htmlFor="Brands">Brands</label>
                     <input type="text" className="form-control" id="Brands" aria-describedby="Brands"/>
                  </div>
                  <div className="form-group">
                     <label htmlFor="location">Locations (Country or City)</label>
                     <select className="form-control" id="loaction">
                        <option>India</option>
                        <option>USA</option>
                        <option>UK</option>
                        <option>Africa</option>
                        <option>UAE</option>
                     </select>
                  </div>
                  <div className="form-group">
                     <label htmlFor="hash-tag-caption">Hashtag or caption</label>
                     <input type="text" className="form-control" id="hash-tag-caption" aria-describedby="hash-tag-caption"/>
                  </div>
                  <div className="form-group">
                     <div className="row">
                        <div className="col-6">
                           <label htmlFor="from">From</label>
                           <div className="input-group date" id="datetimepicker1">
                              <input id="datepicker" width="100%" className="form-control hasDatepicker"/>
                              <span className="input-group-addon">
                              <i className="fa fa-calendar-o" aria-hidden="true"></i>
                              </span>
                           </div>
                        </div>
                        <div className="col-6">
                           <label htmlFor="to">To</label>
                           <div className="input-group date" id="datetimepicker2">
                              <input id="datepicker2" width="100%" className="form-control hasDatepicker"/>
                              <span className="input-group-addon">
                              <i className="fa fa-calendar-o" aria-hidden="true"></i>
                              </span>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div className="form-group radiored-btn">
                     <label className="radio-inline">
                     <input type="checkbox" id="defaultCheck" name="example2"/>
                     <label htmlFor="defaultCheck">Only show sponsored Content</label>
                     </label>
                  </div>
                  <div className="form-group">
                     <label htmlFor="Interests">Interests</label>
                     <input type="text" className="form-control" id="Interests" aria-describedby="Interests"/>
                  </div>
               </form>
               <div className="col-12  mt-5 mb-3 st-txt p-0 ">
                  <h4 style={{fontSize:"18px"}}>Sort By</h4>
                  <div className="btn-group text-center" role="group" aria-label="Basic example">
                     <button type="button" className="btn red btn-light ">Recency</button>
                     <button type="button" className="btn red btn-light">Likes</button>
                     <button type="button" className="btn red btn-light">Comments</button>
                  </div>
               </div>
               <div className="form-group mb-5">
                  <div className="r-btns">
                     <ul>
                        <li><a href="#" className="btn btn-md btn-danger">RESET</a></li>
                        <li><a href="#" className="btn btn-md btn-danger">SEARCH</a></li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </div></section>
        </>
    )
}
export default ContentFilter;
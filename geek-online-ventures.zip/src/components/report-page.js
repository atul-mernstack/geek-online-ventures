import {Button} from 'reactstrap';
import {useHistory} from 'react-router-dom';
import './style.css';
 
const Report=()=>{
   const history=useHistory();
    return(
        <>
        <section className="trend-dashboard">
         <div className="container-fluid mt-4">
         <div className="row text-start">
            <div className="col-12">
               <form>
                  <div className="form-group">
                     <label for="Report-title">Report Title</label>
                     <input type="text" className="form-control" id="Report-title" aria-describedby="Report-title" placeholder="Dyson Stories Report"/>
                  </div>
                  <div className="form-group">
                     <label for="Hashtag">Hashtag</label>
                     <input type="text" className="form-control" id="Hashtag" aria-describedby="Hashtag" placeholder="#dyson (one on each line)"/>
                  </div>
                  <div className="form-group">
                     <label for="Hashtag">Mentions</label>
                     <input type="text" className="form-control" id="Mentions" aria-describedby="Mentions" placeholder="@username (one on each line)"/>
                  </div>
                  <div className="form-group">
                     <label for="influencerusernames">Influencer Usernames</label>
                     <input type="text" className="form-control" id="influencerusernames" aria-describedby="influencerusernames" placeholder="@username (one on each line)"/>
                  </div>
                  <div className="form-group radiored-btn mt-5">
                     <label className="radio-inline">
                     <input type="checkbox" id="defaultCheck" name="example2"/>
                     <label for="defaultCheck">Schedule this report over a period of time</label>
                     </label>
                  </div>
               </form>
               <div className="form-group ">
                  <div className="r-btns">
                     <ul>
                        <li><Button type="button" onClick={()=>{history.push('/influencers-list');}} color="danger"><img style={{height:"30px"}} src={"/images/report.png"}/>Get Report</Button></li>
                     </ul>
                  </div>
               </div>
            </div>
            <div className="border-bottom"></div>
            <div className="bt-txt mb-5">
               <h3>Schedule Reports
               </h3>
               <p>There are no scheduled reports at the moment</p>
            </div>
         </div>
      </div></section>
        </>
    )
}

export default Report;
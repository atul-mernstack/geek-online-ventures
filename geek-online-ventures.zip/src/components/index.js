import { Button } from 'reactstrap';
import {useHistory,Link} from 'react-router-dom';
import './style.css';
const Home=()=>{
    const history=useHistory();
    const signupLoginHandle=()=>{
        history.push('/signup-login');
    }
    return(
        <div className="container">
            <div className="row">
               <div className="col-12 col-md-12 col-sm-12 col-lg-12 ">
                  <div className="thread-white-logo">
                     <img style={{width:"25%", height:"auto"}} src={"/images/thread-red-logo.png"} alt="" className="img-fluid"/>
                  </div>
               </div>
               <div className="col-12 col-md-12 col-sm-12 col-lg-12 ">
                  <div className="thread-center-content">
                     <h2>Sign Up/Log In As</h2>
                     <div className="sl-btns">
                        <Button type="button" color="danger" size="lg" onClick={signupLoginHandle} style={{width:"40%", marginTop:"2em", marginBottom:"2em", borderRadius:"15px"}}>
                           B R A N D</Button>
                     </div>
                     <div className="infulence-btn">
                        <Link to="#">
                           <div className="fill" >
                           
                           </div>
                        </Link>
                     </div>
                  </div>
               </div>
               <div className="col-12 col-md-12 col-sm-12 col-lg-12 ">
                  <div className="thread-bottom-logo">
                     <img style={{width:"25%", height:"auto", marginTop:"5em"}} src={"/images/bounty-logo.png"} className="img-fluid"/>
                  </div>
               </div>
            </div>
            <div className="row">
               <div className="col-12 col-md-12 col-sm-12 col-lg-12 text-center">
                  <div className="privacy-btns">
                     <ul>
                        <li><a href="#">Privacy Ploicy</a></li>
                        | 
                        <li><a href="#">Terms &amp; Conditions</a></li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
    
    )
}
export default Home;
import {Link} from 'react-router-dom';
import './style.css';

const Category=()=>{
    return(
        <>
            <section className="category-sec">
         <div className="container-fluid mt-4">
         <div className="row">
            <div className="col-4 ">
               <div className="user-left">
                  <img src={"/images/nkf-P92_.jpg"} className="img-fluid"/>
               </div>
            </div>
            <div className="col-8 ">
               <div className="para-sec">
                  <button type="button" className="btn btn-light view-btn text-right">View Detailed Analytics</button>
                  <h4>Virat Kholi</h4>
                  <p>Carpediem! @one&amp;world</p>
                  <ul>
                     <li><a href="#"><img src={"/images/user.png"}/>7257</a></li>
                     <li><a href="#"><img src={"/images/user.png"}/>India</a></li>
                     <li><a href="#"><img src={"/images/user.png"}/>above $5000</a></li>
                  </ul>
                  <div className="social-icons">
                     <ul>
                        <li><Link to="/linkaccount"><img src={"/images/fb2.png"} className="img-fluid"/></Link></li>
                        <li><Link to="/linkaccount"><img src={"/images/insta01.png"} className="img-fluid"/></Link></li>
                        <li><Link to="/linkaccount"><img src={"/images/tiktok.png"} className="img-fluid"/></Link></li>
                        <li><Link to="/linkaccount"><img src={"/images/twitter2.png"} className="img-fluid"/></Link></li>
                        <li><Link to="/linkaccount"><img src={"/images/youtube01.png"} className="img-fluid"/></Link></li>
                     </ul>
                     <button type="button" className="btn btn-light view-btn2 text-right"><img src={"/images/upload.png"}/> Upload Influencers</button>
                  </div>
               </div>
            </div>
         </div>
         <div className="row">
            <div className="col-12 text-center">
               <div className="g-btn">
                  <ul>
                     <li><a href="#" className="btn btn-sm btn-danger"><img src={"/images/group.png"} className="img-fluid"/> Add to Group</a></li>
                     <li><a href="#" className="btn btn-sm btn-danger"><img src={"/images/export.png"} className="img-fluid"/> Export Selected</a></li>
                     <li><a href="#" className="btn btn-sm btn-danger"><img src={"/images/mail-2.png"} className="img-fluid"/> Export Selected</a></li>
                  </ul>
               </div>
               <hr></hr>
            </div>
         </div>
         <div className="row">
            <div className="col-12 text-left">
               <div className="cat-txt text-center">
                  <h4 className="text-left text-danger" style={{textDecorationColor:"red"}}>Category</h4>
                  <div className="g-btn2">
                     <ul>
                        <li><a href="#" className="btn btn-sm btn-secondary">Fitness</a></li>
                        <li><a href="#" className="btn btn-sm btn-secondary">Fashion </a></li>
                        <li><a href="#" className="btn btn-sm btn-secondary"> Sports</a></li>
                     </ul>
                  </div>
               </div>
               <hr></hr>
            </div>
         </div>
         <div className="row">
            <div className="col-12 text-left">
               <div className="cat-txt text-center">
                  <h4 className="text-left text-danger">Engagement</h4>
                  <p>&nbsp;</p>
                  <br></br>
                  <p>&nbsp;</p>
                  <br></br>
               </div>
               <hr></hr>
            </div>
         </div>
         <div className="row">
            <div className="col-12 text-left">
               <div className="cat-txt text-center">
                  <h4 className="text-left text-danger">Similar Influcencers</h4>
                  <p>&nbsp;</p>
                  <br></br>
                  <p>&nbsp;</p>
                  <br></br>
               </div>
               <hr></hr>
            </div>
         </div>
      </div></section>
        </>
    )
}

export default Category;
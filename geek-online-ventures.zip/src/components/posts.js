import './style.css';
 
const Post=()=>{
    return(
        <>
        <div className="container mt-5 mb-5">
            <div className="row text-center">
                <div className="col-12">
                    <div>
                        <img style={{width:"100%"}} src={'/images/posts-bg.png'} alt="" />
                    </div>
                </div>
            </div>
        </div>
        </>
    )
}

export default Post;